#!/bin/sh
#
for x in 0*
do
  ./run_test.sh $x create_output_masters
done